/**
 * msgnuke.js  Synchronet message base keyword deleter
 *
 * Reads kill words from c:\sbbs\text\msgnuke.can (one word/phrase per line).
 * Scans all sub-boards (or a specified one) and deletes any message whose
 * subject, body, OR author (From field) contains any word/name from that
 * file.
 *
 * Format of msgnuke.can:
 *   # Lines starting with # are comments and are ignored
 *   # Blank lines are ignored
 *   buy cheap meds
 *   casino
 *   http://evil.example.com
 *   FREE MONEY
 *   Spammy McSpamface     <- an author name works too (see -noauthor)
 *
 * Run with jsexec:
 *   jsexec msgnuke.js [options]
 *
 * Options:
 *   -can <path>    Override path to .can file
 *                  (default: c:\sbbs\text\msgnuke.can)
 *   -sub <code>    Only scan this sub-board internal code
 *   -subj          Search subject line only (default: subject + body [+ author])
 *   -body          Search body only
 *   -noauthor      Do NOT match keywords against the message header's
 *                  From (author) field  (default: author matching is ON)
 *   -case          Case-sensitive match (default: case-insensitive)
 *   -dry           Dry run  report matches but do NOT delete
 *   -from <name>   Only consider messages from this author (exact filter,
 *                  independent of the keyword-based author matching above)
 *   -confirm       Prompt before deleting each message
 *   -log <file>    Write a log of all matches/deletions to a file
 *   -list          Print the loaded word list and exit
 *
 * Examples:
 *   jsexec msgnuke.js
 *   jsexec msgnuke.js -dry
 *   jsexec msgnuke.js -sub SYNCNET -dry
 *   jsexec msgnuke.js -can c:\sbbs\text\mylist.can -log nuke.log
 *
 * Requires: Synchronet 3.14+ with jsexec
 */

"use strict";
load("sbbsdefs.js");

// Synchronet's SpiderMonkey doesn't have String.prototype.repeat
function strRep(ch, n) {
    var s = "";
    for (var i = 0; i < n; i++) s += ch;
    return s;
}

// -- Defaults ------------------------------------------------------------------
var CAN_FILE    = "c:\\sbbs\\text\\msgnuke.can";
var targetSub   = "";
var searchSubj  = true;
var searchBody  = true;
var searchAuthor = true;
var caseSens    = false;
var dryRun      = false;
var fromFilter  = "";
var confirmEach = false;
var logFile     = "";
var listOnly    = false;

// -- Parse arguments -----------------------------------------------------------
for (var i = 0; i < argv.length; i++) {
    switch (argv[i]) {
        case "-can":     CAN_FILE    = argv[++i] || CAN_FILE;  break;
        case "-sub":     targetSub   = argv[++i] || "";        break;
        case "-subj":    searchSubj  = true;  searchBody = false; break;
        case "-body":    searchBody  = true;  searchSubj = false; break;
        case "-noauthor": searchAuthor = false;                 break;
        case "-case":    caseSens    = true;                   break;
        case "-dry":     dryRun      = true;                   break;
        case "-from":    fromFilter  = argv[++i] || "";        break;
        case "-confirm": confirmEach = true;                   break;
        case "-log":     logFile     = argv[++i] || "";        break;
        case "-list":    listOnly    = true;                   break;
        case "-help": case "--help": case "-?":
            print("Usage: jsexec msgnuke.js [options]");
            print("  -can <path>   Path to kill-word file (default: " + CAN_FILE + ")");
            print("  -sub <code>   Scan only this sub-board code");
            print("  -subj         Search subject only");
            print("  -body         Search body only");
            print("  -noauthor     Don't match keywords against author (From) field");
            print("  -case         Case-sensitive matching");
            print("  -dry          Dry run, no deletions");
            print("  -from <name>  Also filter by author name");
            print("  -confirm      Prompt before each deletion");
            print("  -log <file>   Write log to file");
            print("  -list         Print loaded word list and exit");
            exit(0);
        default:
            print("Unknown option: " + argv[i] + "  (use -help for usage)");
            break;
    }
}

// -- Logging -------------------------------------------------------------------
var logF = null;
if (logFile) {
    logF = new File(logFile);
    if (!logF.open("w")) {
        print("WARNING: Cannot open log file: " + logFile);
        logF = null;
    }
}

function log(msg) {
    print(msg);
    if (logF) logF.writeln(msg);
}

// -- Load kill-word list from .can file ----------------------------------------
function loadCanFile(path) {
    if (!file_exists(path)) {
        log("ERROR: Kill-word file not found: " + path);
        log("");
        log("Create it at that path with one word or phrase per line.");
        log("Lines starting with # are comments.  Example:");
        log("  # spam keywords");
        log("  buy cheap meds");
        log("  casino bonus");
        log("  http://spammer.example.com");
        exit(1);
    }

    var f = new File(path);
    if (!f.open("r")) {
        log("ERROR: Cannot open kill-word file: " + path);
        exit(1);
    }

    var words   = [];
    var skipped = 0;
    var ln;
    while ((ln = f.readln(1024)) !== null) {
        // Strip leading/trailing whitespace
        var trimmed = ln.replace(/^\s+|\s+$/g, "");
        // Skip blank lines and comments
        if (!trimmed || trimmed.charAt(0) === "#") {
            skipped++;
            continue;
        }
        words.push(trimmed);
    }
    f.close();
    return words;
}

var keywords = loadCanFile(CAN_FILE);

if (keywords.length === 0) {
    log("ERROR: No keywords found in " + CAN_FILE);
    log("Add at least one word or phrase (one per line).");
    exit(1);
}

// -- Banner --------------------------------------------------------------------
function banner() {
    log(strRep("=", 62));
    log("  Synchronet Message Base Keyword Deleter");
    log(strRep("=", 62));
    log("  Kill-word file : " + CAN_FILE);
    log("  Keywords loaded: " + keywords.length);
    log("  Search in      : " + (searchSubj && searchBody ? "subject + body"
                                : searchSubj ? "subject only" : "body only"));
    log("  Author match   : " + (searchAuthor ? "ON  (keywords also matched against From field)" : "off"));
    log("  Case           : " + (caseSens ? "sensitive" : "insensitive"));
    log("  Sub-board      : " + (targetSub || "ALL"));
    log("  From filter    : " + (fromFilter || "(any author)"));
    log("  Mode           : " + (dryRun ? "DRY RUN  no deletions" : "LIVE DELETE"));
    log("  Date/Time      : " + new Date().toLocaleString());
    log(strRep("=", 62));
}

// -- -list mode  just print keywords and exit ---------------------------------
if (listOnly) {
    log("Kill-word file: " + CAN_FILE);
    log("Keywords (" + keywords.length + "):");
    for (var i = 0; i < keywords.length; i++)
        log("  [" + (i+1) + "] " + keywords[i]);
    exit(0);
}

banner();

// -- Match helpers -------------------------------------------------------------
// Returns the matching keyword if found, or null
function findMatch(text) {
    if (!text) return null;
    var haystack = caseSens ? text : text.toLowerCase();
    for (var i = 0; i < keywords.length; i++) {
        var needle = caseSens ? keywords[i] : keywords[i].toLowerCase();
        if (haystack.indexOf(needle) !== -1)
            return keywords[i];
    }
    return null;
}

function matchesFrom(from) {
    if (!fromFilter) return true;
    if (!from) return false;
    return from.toLowerCase().indexOf(fromFilter.toLowerCase()) !== -1;
}

// -- Sub-board list ------------------------------------------------------------
function getSubBoards() {
    var subs = [];
    if (targetSub) {
        if (msg_area.sub[targetSub] === undefined) {
            log("ERROR: Sub-board code not found: " + targetSub);
            log("Valid codes:");
            for (var code in msg_area.sub)
                log("  " + code + "    " + msg_area.sub[code].name);
            exit(1);
        }
        subs.push({ code: targetSub, name: msg_area.sub[targetSub].name });
    } else {
        for (var code in msg_area.sub)
            subs.push({ code: code, name: msg_area.sub[code].name });
        subs.sort(function(a,b){ return a.code < b.code ? -1 : 1; });
    }
    return subs;
}

// -- Delete one message --------------------------------------------------------
// Use remove_msg()  the correct MsgBase method for marking a message deleted.
// remove_msg(by_offset, number_or_offset) marks the message deleted in the
// index and header without the duplicate-ID checks that save_msg() performs.
function deleteMessage(mb, hdr, subName) {
    // remove_msg(by_offset=false, msg_number)  marks message as deleted
    var result = mb.remove_msg(false, hdr.number);
    if (!result) {
        log("  !! remove_msg failed for #" + hdr.number + " in " + subName);
        log("     mb.error=" + (mb.error !== undefined ? mb.error : "n/a"));
        return false;
    }
    return true;
}

// -- Scan one sub-board --------------------------------------------------------
function scanSub(subCode, subName) {
    var mb = new MsgBase(subCode);
    // Open read-write so save_msg() can write back the updated header
    if (!mb.open()) {
        log("  [SKIP] Cannot open: " + subCode + " (" + subName + ")");
        return { scanned:0, matched:0, deleted:0 };
    }

    if (mb.last_msg < 1 || mb.last_msg < mb.first_msg) {
        mb.close();
        return { scanned:0, matched:0, deleted:0 };
    }

    var total   = mb.last_msg - mb.first_msg + 1;
    var scanned = 0, matched = 0, deleted = 0;

    log("\nScanning: " + subName + " (" + subCode + ")    " +
        total + " message(s)");

    for (var num = mb.first_msg; num <= mb.last_msg; num++) {
        // Get index first  contains the offset needed by save_msg
        var idx = mb.get_msg_index(false, num);
        if (!idx) continue;
        if (idx.attr & MSG_DELETE) continue;   // already deleted (fast check)

        // Get full header (includes offset, number, subject, from, attr, etc.)
        var hdr = mb.get_msg_header(false, num);
        if (!hdr) continue;
        if (hdr.attr & MSG_DELETE) continue;   // double-check on header

        scanned++;

        // Author filter
        if (!matchesFrom(hdr.from)) continue;

        // Check author (From field) first  cheapest check, already in the header
        var hitWord  = null;
        var hitWhere = "";

        if (searchAuthor) {
            hitWord = findMatch(hdr.from);
            if (hitWord) hitWhere = "author";
        }

        // Check subject next (still cheap, no extra I/O)
        if (!hitWord && searchSubj) {
            hitWord = findMatch(hdr.subject);
            if (hitWord) hitWhere = "subject";
        }

        // Check body last (requires fetching the message body)
        if (!hitWord && searchBody) {
            var body = mb.get_msg_body(false, num);
            hitWord  = findMatch(body);
            if (hitWord) hitWhere = "body";
        }

        if (!hitWord) continue;

        matched++;
        var preview = (hdr.subject || "(no subject)").slice(0, 52);
        var fromStr = (hdr.from    || "(unknown)"   ).slice(0, 28);
        var dateStr = (hdr.when_written_date || "").toString();

        log("  [MATCH #" + hdr.number + "] \"" + preview + "\"");
        log("    From   : " + fromStr);
        log("    Date   : " + dateStr);
        log("    Trigger: \"" + hitWord + "\" in " + hitWhere);

        if (dryRun) {
            log("    >> DRY RUN  not deleted");
            continue;
        }

        var doDelete = true;
        if (confirmEach) {
            var ans = prompt("    Delete this message? [y/N] ");
            doDelete = (ans && ans.toLowerCase() === "y");
        }

        if (doDelete) {
            if (deleteMessage(mb, hdr, subName)) {
                deleted++;
                log("    >> DELETED");
            }
        } else {
            log("    >> Skipped");
        }
    }

    mb.close();

    log("  Result: scanned=" + scanned +
        "  matched=" + matched + "  deleted=" + deleted);

    return { scanned:scanned, matched:matched, deleted:deleted };
}

// -- Main ----------------------------------------------------------------------
var subs   = getSubBoards();
var totals = { scanned:0, matched:0, deleted:0 };

for (var i = 0; i < subs.length; i++) {
    var r = scanSub(subs[i].code, subs[i].name);
    totals.scanned += r.scanned;
    totals.matched += r.matched;
    totals.deleted += r.deleted;
}

log("\n" + strRep("=", 62));
log("  SUMMARY");
log("  Kill-word file     : " + CAN_FILE);
log("  Sub-boards scanned : " + subs.length);
log("  Messages scanned   : " + totals.scanned);
log("  Messages matched   : " + totals.matched);
log("  Messages deleted   : " + (dryRun ? "0 (dry run)" : totals.deleted));
log(strRep("=", 62));

if (logF) {
    logF.close();
    print("Log written to: " + logFile);
}

if (dryRun && totals.matched > 0)
    print("\nRe-run without -dry to delete " + totals.matched + " message(s).");